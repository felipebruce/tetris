#ifndef PECA_H_INCLUDED
#define PECA_H_INCLUDED
int Tipo_Do_Bloco (int p, int r, int x, int y);
void Armazenar_Peca(int x, int y, int peca, int rot);


#endif // PECA_H_INCLUDED
