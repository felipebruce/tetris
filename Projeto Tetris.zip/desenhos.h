#ifndef DESENHOS_H_INCLUDED
#define DESENHOS_H_INCLUDED

void Desenhar_Peca (int peca, int rot, int b, int a);
void Desenhar_Peca_Visualizada(int peca, int rot, int b, int a);
void Matriz_Inicial();
void Matriz_Atualizada();
void Titulo_Menu();

#endif // DESENHOS_H_INCLUDED
