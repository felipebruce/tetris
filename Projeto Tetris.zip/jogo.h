#ifndef JOGO_H_INCLUDED
#define JOGO_H_INCLUDED

void Deletar();
void Iniciar_Jogo();
void Jogo();
void Instrucoes();
void Nova_Peca(int *c, int *d);

#endif // JOGO_H_INCLUDED
