#ifndef RANKING_H_INCLUDED
#define RANKING_H_INCLUDED

void Escreve(int pontos);
void Organizar_Por_Pontuacao(int pontuacao[20],char nomes[20][255], int tamanho);
void Leitura_Ranking();

#endif // RANKING_H_INCLUDED
