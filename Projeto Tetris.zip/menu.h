#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void Menu();

#endif // MENU_H_INCLUDED
