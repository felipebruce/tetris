#ifndef VERIFICACOES_H_INCLUDED
#define VERIFICACOES_H_INCLUDED

char Sem_Blocos_Matriz (int x, int y);
char Check(int x, int y, int peca, int rot);
char Verificar_fim_jogo();
void Deletar_Linha(int lin);
void gotoxy(int x,int y);

#endif // VERIFICACOES_H_INCLUDED
